=======================================================================
SUBMISSION PACKAGE
AI Tools for Research - Lab Exercise
Scientific Writing Using Prism and LaTeX
=======================================================================

Paper converted:
  "Safety and Rollback Mechanisms for Objective Misinterpretation
   in Agentic AI Systems"

-----------------------------------------------------------------------
1. FOLDER CONTENTS
-----------------------------------------------------------------------

StudentName_RollNumber/
  |-- Original_Paper.pdf        Original manuscript (converted from the
  |                             supplied .docx)
  |-- main.tex                  Complete LaTeX manuscript
  |-- references.bib            6 verified BibTeX entries
  |-- Figures/                  5 evidence screenshots, meaningfully named
  |-- Prism_Final_Paper.pdf     Compiled output (12 pages)
  |-- Overleaf_Final_Paper.pdf  Compiled output (12 pages)
  |-- Prompt_Log.docx           Part M - 11 prompts
  |-- Error_Log.docx            Part I - 8 documented problems
  |-- Reflection.docx           Part O - reflection + Q46-52
  |-- Lab_Worksheet.docx        Parts B, D, E, H, J, K, L, N completed
  `-- README.txt                This file

-----------------------------------------------------------------------
2. HOW TO COMPILE
-----------------------------------------------------------------------

The build sequence matters - a single pdflatex run leaves citations
and cross-references unresolved:

    pdflatex main.tex
    bibtex   main
    pdflatex main.tex
    pdflatex main.tex

On Overleaf this happens automatically, but set main.tex as the main
document first (Menu > Main document) if it is not detected.

Final status: 0 errors, 0 undefined citations, 0 undefined references,
0 overfull boxes, 12 pages.

-----------------------------------------------------------------------
3. REQUIREMENTS COVERAGE
-----------------------------------------------------------------------

  Complete conversion into LaTeX ................ DONE
  >=1 equation converted & cross-referenced ..... NOT APPLICABLE.
        The paper contains no equations. This is stated explicitly
        in the PDF ("Note on Mathematical Content") and in Part D
        of the Lab Worksheet, as the exercise sheet permits.
  >=1 table converted to LaTeX .................. DONE (Table 1,
        recreating the five-layer model of Section 10 verbatim)
  >=1 figure inserted & cross-referenced ........ DONE (5 figures)
  >=5 verified references via BibTeX ............ DONE (6)
  >=4 working cross-references .................. DONE (sections,
        subsections, table, figures, citations - all resolve)
  >=3 documented LaTeX errors and fixes ......... DONE (8)
  >=5 meaningful Prism prompts .................. DONE (11)
  Original vs Prism-assisted paragraph .......... DONE (Part J)
  Prism-to-Overleaf portability test ............ DONE (Part L)

-----------------------------------------------------------------------
4. WHAT YOU MUST STILL DO BEFORE SUBMITTING
-----------------------------------------------------------------------

These items cannot be completed for you. Please do not submit without
them.

(a) RENAME THE FOLDER
    Change "StudentName_RollNumber" to your actual name and roll
    number, per the naming convention in Section 5 of the exercise
    sheet.

(b) FILL IN THE AUTHOR BLOCK
    main.tex currently contains a placeholder author block (marked
    with a TODO comment, around line 55). Replace it with the author
    name(s), affiliation(s) and email exactly as they appear on your
    original manuscript. The supplied .docx did not list them.
    Then recompile.

(c) FILL IN NAME AND ROLL NUMBER
    Each .docx has a cover table with blank Student Name and Roll No.
    fields.

(d) RESOLVE THE MISSING CITATION [7]
    Your original manuscript cites source [7] in Section 7
    ("Constitutional approaches...") but its reference list ends at
    [6]. No reference was invented to cover this - that would breach
    the assignment's rule against unsupported citations. Either add
    the intended source to references.bib and replace the literal
    "[7]" in main.tex with \cite{yourkey}, or delete the marker if it
    was typed in error. The location is marked with a comment block
    in main.tex. This is also recorded in Error_Log problem 1 and in
    Part K of the Lab Worksheet.

(e) RUN THE PROJECT THROUGH PRISM AND OVERLEAF YOURSELF
    The two PDFs in this folder were produced from main.tex with a
    standard pdflatex + bibtex toolchain. The LaTeX source is
    platform-independent, so Prism and Overleaf will produce the same
    document - but the exercise is assessing that YOU used those two
    platforms. Upload this project to both, compile, and replace
    Prism_Final_Paper.pdf and Overleaf_Final_Paper.pdf with your own
    output. Keep any screenshots your instructor asks for.

-----------------------------------------------------------------------
5. CONVERSION INTEGRITY
-----------------------------------------------------------------------

This was treated as a conversion exercise, not a paper-generation
exercise. Specifically:

  - No scientific claim was added, removed, reworded or reinterpreted.
  - No numerical value was changed (the paper contains none).
  - No equation was invented to satisfy the equation requirement.
  - No citation, DOI, publisher or page range was fabricated. Where a
    field was missing from the source (the publisher of the Russell
    chapter) it was left empty rather than guessed, which is why one
    harmless BibTeX warning remains.
  - Table 1 reorganises the presentation of Section 10 only. Its layer
    numbers, names and descriptions are verbatim.
  - The improved paragraph from Part J was deliberately NOT merged
    into main.tex, so that the manuscript preserves the original
    wording.

=======================================================================
